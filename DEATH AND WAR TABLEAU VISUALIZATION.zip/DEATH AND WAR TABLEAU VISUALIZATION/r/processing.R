#fetching raw dataset
setwd("Z:/PROJECTS/DEATH AND WAR TABLEAU VISUALIZATION/raw dataset")
raw<-read.csv("INTRA-STATE_State_participants v5.1 CSV.csv",na.strings = c(-8,-9))

#change column name
colnames(raw)<-c("War Number","War Name","Region of War","War Type","Primary Participant Country Code Side A","Side A","Primary Participant Country Code Side B","Side B","International","Start Month 1","Start Day 1","Start Year 1","End Month 1","End Day 1","End Year 1","Start Month 2","Start Day 2","Start Year 2","End Month 2","End Day 2","End Year 2","Start Month 3","Start Day 3","Start Year 3","End Month 3","End Day 3","End Year 3","Start Month 4","Start Day 4","Start Year 4","End Month 4","End Day 4","End Year 4","Duration (in days)","Duration (in months)","Transformed from","Initiator","Outcome","Transformed to","Death Count Side A","Death Count Side B","Total Death Count","Total Military Forces Side A (Active+Reserved)","Total Military Forces Side A Active","Total Military Forces Side B (Active+Reserved)","Total Military Forces Side B Active","Version")

#pre processing  wars dataset
raw$`Start Date 1` <- as.Date(paste(raw$`Start Year 1`, raw$`Start Month 1`, raw$`Start Day 1`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("Start Year 1", "Start Month 1", "Start Day 1"))]
raw$`End Date 1` <- as.Date(paste(raw$`End Year 1`, raw$`End Month 1`, raw$`End Day 1`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("End Year 1", "End Month 1", "End Day 1"))]

raw$`Start Date 2` <- as.Date(paste(raw$`Start Year 2`, raw$`Start Month 2`, raw$`Start Day 2`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("Start Year 2", "Start Month 2", "Start Day 2"))]
raw$`End Date 2` <- as.Date(paste(raw$`End Year 2`, raw$`End Month 2`, raw$`End Day 2`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("End Year 2", "End Month 2", "End Day 2"))]


raw$`Start Date 3` <- as.Date(paste(raw$`Start Year 3`, raw$`Start Month 3`, raw$`Start Day 3`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("Start Year 3", "Start Month 3", "Start Day 3"))]
raw$`End Date 3` <- as.Date(paste(raw$`End Year 3`, raw$`End Month 3`, raw$`End Day 3`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("End Year 3", "End Month 3", "End Day 3"))]

raw$`Start Date 4` <- as.Date(paste(raw$`Start Year 4`, raw$`Start Month 4`, raw$`Start Day 4`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("Start Year 4", "Start Month 4", "Start Day 4"))]
raw$`End Date 4` <- as.Date(paste(raw$`End Year 4`, raw$`End Month 4`, raw$`End Day 4`, sep = "-"),format="%Y-%m-%d")
raw <- raw[, !(names(raw) %in% c("End Year 4", "End Month 4", "End Day 4"))]

raw <- raw[, !(names(raw) %in% c("Primary Participant Country Code Side A","Primary Participant Country Code Side B","Version"))]

raw$`Region of War`<-as.character(raw$`Region of War`)
raw$`Region of War`[raw$`Region of War`=="1"]<-"North America"
raw$`Region of War`[raw$`Region of War`=="2"]<-"South America"
raw$`Region of War`[raw$`Region of War`=="3"]<-"Europe"
raw$`Region of War`[raw$`Region of War`=="4"]<-"Sub-Saharan Africa"
raw$`Region of War`[raw$`Region of War`=="5"]<-"Middle East and North Africa"
raw$`Region of War`[raw$`Region of War`=="6"]<-"Asia and Oceania"

raw$`War Type`[raw$`War Type`=="4"]<-"Civil War for Central Control"
raw$`War Type`[raw$`War Type`=="5"]<-"Civil War for Local Issues"
raw$`War Type`[raw$`War Type`=="6"]<-"Regional Internal"
raw$`War Type`[raw$`War Type`=="7"]<-"Inter-Communal"


raw$International<-as.character(raw$International)
raw$International[raw$International==1]<-"Yes"
raw$International[raw$International==0]<-"No"

raw$Outcome<-as.character(raw$Outcome)
raw$Outcome[raw$Outcome=="1"]<-"Side A Wins"
raw$Outcome[raw$Outcome=="2"]<-"Side B Wins"
raw$Outcome[raw$Outcome=="3"]<-"Compromise"
raw$Outcome[raw$Outcome=="4"]<-"Transformed to other kind of War"
raw$Outcome[raw$Outcome=="5"]<-"War ongoing as of 31th Dec, 2014"
raw$Outcome[raw$Outcome=="6"]<-"Stalemate"
raw$Outcome[raw$Outcome=="7"]<-"Conflict continues at below war level"

write.csv(raw,"Z:/PROJECTS/DEATH AND WAR TABLEAU VISUALIZATION/processed dataset/intra-state wars.csv",row.names = F)


#####################################################################################################################


#delete r history file
unlink(".Rhistory",force=T)

#clear plot
dev.off()

# Clear environment
rm(list = ls()) 

#clear console
cat("\014")

